package familylibrarymanager.zhao.com.familylibrarymanager;

import familylibrarymanager.zhao.com.familylibrarymanager.dao.LibraryDBDao;

/**
 * Description: fragment 与 activity 交互 接口
 * Person in charge :  zouyulong
 */

public interface OnFragmentInteractionListener {
    LibraryDBDao getDao();
}
