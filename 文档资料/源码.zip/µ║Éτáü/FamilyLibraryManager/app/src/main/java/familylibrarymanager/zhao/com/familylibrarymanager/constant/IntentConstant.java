package familylibrarymanager.zhao.com.familylibrarymanager.constant;

/**
 * Description: Intent 传递 常量
 * Created by zouyulong on 2017/4/27.
 * Student number:121
 */

public class IntentConstant {
    public static final String INTENT_DAO = "library_dao";

}
